package com.quest.student.studentservice;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.quest.student.entity.Student;
import com.quest.student.repository.StudentRepository;



//I have done the testing with database

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class StudentServiceApplicationTests {
	@Autowired
    StudentRepository studentRepository;
	

	@Test
	@Order(1)
	public void saveStudentTest(){
		
		
		Student s = new Student();
 	    s.setStdId(1L);
		s.setStdName("Dipak");
		s.setStdBranch("cse");
		s.setRollNo(101);
		s.setStdEmail("d@gmail.com");
		studentRepository.save(s);
		assertNotNull(studentRepository.findById(1L).get());
		
		
	}
	
	@Test
	@Order(2)
	public void testReadAll() {
	List<Student> list=	studentRepository.findAll();
	assertThat(list).size().isGreaterThan(0);
		
	}
	
	@Test
	@Order(3)
	public void testSingleStudent() {
		
		Student student = studentRepository.findById(1L).get();
		assertEquals("Dipak", student.getStdName());
		
	}
	
	@Test
	@Order(4)
	public void testUpdate() {
		
		Student s = studentRepository.findById(1L).get();
		s.setStdName("Amruta");
		studentRepository.save(s);
		
		assertNotEquals("Dipak", studentRepository.findById(1L).get().getStdName());
	}
	
	
	@Test
	@Order(5)
	public void testDelete() {
		
		studentRepository.deleteById(1L);
		assertThat(studentRepository.existsById(1L)).isFalse();
	}
	
	
	 
}
