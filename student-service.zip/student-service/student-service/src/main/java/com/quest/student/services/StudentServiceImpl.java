package com.quest.student.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.quest.student.entity.Student;
import com.quest.student.exception.ResourceNotFoundException;
import com.quest.student.repository.StudentRepository;


@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentRepository studentRepository;



	@Override
	public Student saveStudent(Student student) {

		return studentRepository.save(student);
	}

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}

	@Override
	public Student getStudentById(Long StdId) {
		// TODO Auto-generated method stub
		Optional<Student> student = studentRepository.findById(StdId);
		//		if(student.isPresent()) {
		//		
		//		return student.get();
		//	}else {
		//		
		//		throw new ResourceNotFoundException("Student", "StdId", StdId);
		//	}

		return studentRepository.findById(StdId).orElseThrow(()->new ResourceNotFoundException("Student", "StdID", StdId));



	}
	
 

	@Override
	public Student updateStudent(Student student, long stdId) {

		// we need to check wheather student with given id is exist or not


		Student existingStudent  = studentRepository.findById(stdId).orElseThrow(
				()->new ResourceNotFoundException("Student", "StdId", stdId));

		existingStudent.setStdName(student.getStdName());
		existingStudent.setRollNo(student.getRollNo());
		existingStudent.setStdEmail(student.getStdBranch());
		existingStudent.setStdBranch(student.getStdBranch());
		//save existing student to db
		studentRepository.save(existingStudent);
		return existingStudent;
	}

	@Override
	public void deleteStudent(long stdId) {
		//check wheather a student exist in db or not
		studentRepository.findById(stdId).orElseThrow(
				()->new ResourceNotFoundException("Student", "StdId", stdId));

		studentRepository.deleteById(stdId);
	}

	 





}
