package com.quest.student.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity

@Table(name="student")

public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	@Column(name="std_Id")
	private Long  stdId;

	@Column(name="std_Name")
	private String stdName;

	@Column(name="roll_No")
	private int rollNo;

	@Column(name="std_Email")
	private String stdEmail;

	@Column(name="std_Branch")
	private String stdBranch;

	public Student() {
		super();
	}

	public Student(Long stdId, String stdName, int rollNo, String stdEmail, String stdBranch) {
		super();
		this.stdId = stdId;
		this.stdName = stdName;
		this.rollNo = rollNo;
		this.stdEmail = stdEmail;
		this.stdBranch = stdBranch;
	}

	public Long getStdId() {
		return stdId;
	}

	public void setStdId(Long stdId) {
		this.stdId = stdId;
	}

	public String getStdName() {
		return stdName;
	}

	public void setStdName(String stdName) {
		this.stdName = stdName;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getStdEmail() {
		return stdEmail;
	}

	public void setStdEmail(String stdEmail) {
		this.stdEmail = stdEmail;
	}

	public String getStdBranch() {
		return stdBranch;
	}

	public void setStdBranch(String stdBranch) {
		this.stdBranch = stdBranch;
	}

	@Override
	public String toString() {
		return "Student [stdId=" + stdId + ", stdName=" + stdName + ", rollNo=" + rollNo + ", stdEmail=" + stdEmail
				+ ", stdBranch=" + stdBranch + "]";
	}





}
