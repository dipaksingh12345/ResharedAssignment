package com.quest.student.services;

import java.util.List;

import com.quest.student.entity.Student;

public interface StudentService {



	Student saveStudent(Student student);

	List<Student> getAllStudents();

	Student getStudentById(Long StdId);	
	
	 

	Student updateStudent(Student student, long stdId);

	void deleteStudent(long stdId);


}
