package com.quest.admin.sevices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.quest.admin.entity.Book;
import com.quest.admin.entity.IssueBook;
import com.quest.admin.entity.Student;
import com.quest.admin.repository.AdminBookRepository;
import com.quest.admin.response.ResponseTemplate;


@Service
public class AdminSericeImpl implements AdminService {



	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private AdminBookRepository adminBookRepository;

	@Override
	public ResponseTemplate getIssueBook(int issueBookId) {
		ResponseTemplate response = new ResponseTemplate();
		System.out.println("hello");
		IssueBook issueBook = adminBookRepository.getById(issueBookId);
		System.out.println("hello");
		Student std = restTemplate.getForObject("http://localhost:8088/api/student/" + issueBook.getStdId(),
				Student.class);
		System.out.println("hello");
		Book book = restTemplate.getForObject("http://localhost:8082/api/book/" + issueBook.getBookId(), Book.class);
		System.out.println("hello");
		response.setBook(book);
		response.setStudent(std);
		response.setIssueBook(issueBook);
		return response;
	}

	@Override
	public IssueBook saveIssueBook(IssueBook issueBook) {
		// TODO Auto-generated method stub
		return adminBookRepository.save(issueBook);
	}




}
