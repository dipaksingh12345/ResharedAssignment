package com.quest.admin.entity;

 
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class IssueBook  {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 
	private int issueBookId;
	private LocalDate issueDate = LocalDate.now();
	private LocalDate returnDate = issueDate.plusDays(7);
	private Long bookId;
	private Long stdId;
	public IssueBook() {
		super();
	}
	public IssueBook(int issueBookId, LocalDate issueDate, LocalDate returnDate, Long bookId, Long stdId) {
		super();
		this.issueBookId = issueBookId;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		this.bookId = bookId;
		this.stdId = stdId;
	}
	public int getIssueBookId() {
		return issueBookId;
	}
	public void setIssueBookId(int issueBookId) {
		this.issueBookId = issueBookId;
	}
	public LocalDate getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}
	public LocalDate getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}
	public Long getBookId() {
		return bookId;
	}
	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}
	public Long getStdId() {
		return stdId;
	}
	public void setStdId(Long stdId) {
		this.stdId = stdId;
	}
	 
	 

}
