package com.quest.admin.entity;
 
public class Student {



	private Long  stdId;
    private String stdName;
	private int rollNo;
	private String stdEmail;
	private String stdBranch;
    
	public Student() {
		super();
	}

	public Student(Long stdId, String stdName, int rollNo, String stdEmail, String stdBranch) {
		super();
		this.stdId = stdId;
		this.stdName = stdName;
		this.rollNo = rollNo;
		this.stdEmail = stdEmail;
		this.stdBranch = stdBranch;
	}


	public Long getStdId() {
		return stdId;
	}


	public void setStdId(Long stdId) {
		this.stdId = stdId;
	}


	public String getStdName() {
		return stdName;
	}


	public void setStdName(String stdName) {
		this.stdName = stdName;
	}


	public int getRollNo() {
		return rollNo;
	}


	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}


	public String getStdEmail() {
		return stdEmail;
	}


	public void setStdEmail(String stdEmail) {
		this.stdEmail = stdEmail;
	}


	public String getStdBranch() {
		return stdBranch;
	}


	public void setStdBranch(String stdBranch) {
		this.stdBranch = stdBranch;
	}


	@Override
	public String toString() {
		return "Student [stdId=" + stdId + ", stdName=" + stdName + ", rollNo=" + rollNo + ", stdEmail=" + stdEmail
				+ ", stdBranch=" + stdBranch + "]";
	}




}

