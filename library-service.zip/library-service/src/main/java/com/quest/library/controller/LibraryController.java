package com.quest.library.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quest.library.entity.Book;
import com.quest.library.services.LibraryService;

@RestController
@RequestMapping("/api/book")
public class LibraryController {


	@Autowired
	private LibraryService libraryservice;

	//build create book rest api
	//It will be used to handle post Http request
	//post mapping contains json object thats need to be bind with java object so we used @RequestBodey
	@PostMapping("/addbook")
	public ResponseEntity<Book>addbook(@RequestBody Book book){
		return new ResponseEntity<Book>(libraryservice.addbook(book), HttpStatus.CREATED);
	}

	//build get all books rest api
	@GetMapping("/getallbooks")

	public List<Book> getAllBooks(){
		return libraryservice.getAllBooks();
	}


	//build get bookbyid restapi
//http:;;localhost/api/admin/3
	@GetMapping("{id}")
	public ResponseEntity<Book> getBookById(@PathVariable("id")  long bookId){
		return new ResponseEntity<Book>(libraryservice.getBookById(bookId),HttpStatus.OK);
	}


	//build update book rest api
	//path variable{id} this is basically a urltemplate variable
	@PutMapping("{id}")
	public ResponseEntity<Book> updateBook(@PathVariable("id") long bookId, @RequestBody Book book){
		return  new ResponseEntity<Book>(libraryservice.updateBook(book, bookId),HttpStatus.OK);


	}


	//build deletebook restapi

	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteBook(@PathVariable("id") long bookId){

		libraryservice.deleteBook(bookId);
		return new ResponseEntity<String>("Book deleted successfully!!", HttpStatus.OK);


	}
	@GetMapping("/booksort")
	public List<Book>sortBook(){
		return libraryservice.sortBook();

	}


	@GetMapping("/searchBySubject/{subject}")
	public List<Book> searchBookByName(@PathVariable("subject")  String subject){
		return libraryservice.searchBookByName(subject);


	}








}

