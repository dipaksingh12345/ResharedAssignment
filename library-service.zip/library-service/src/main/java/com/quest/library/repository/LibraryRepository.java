package com.quest.library.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.quest.library.entity.Book;



//it requires two parameter entity name and their id
//Repository:-It is a class level annotation the repository is a dao that access data directly,and perform all the operation related to the database
@Repository
public interface LibraryRepository extends  JpaRepository<Book, Long> {

}
